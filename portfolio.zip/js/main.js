// Minimal JS: fake contact send & smooth scroll
function submitContact(e){
  e.preventDefault();
  var status = document.getElementById('formStatus');
  status.textContent = "Sending...";
  setTimeout(function(){
    status.textContent = "Message sent (demo). I'll get back to you!";
    document.getElementById('contactForm').reset();
  }, 900);
  return false;
}
// smooth anchor scrolling
document.querySelectorAll('.nav a').forEach(a=>{
  a.addEventListener('click',function(e){
    e.preventDefault();
    var id = this.getAttribute('href').slice(1);
    document.getElementById(id).scrollIntoView({behavior:'smooth'});
  });
});
