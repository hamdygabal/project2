Hamdy Portfolio - simple static site
------------------------------------
This is a ready-to-use static portfolio site (HTML/CSS/JS).
To deploy:
- Upload the contents of the `site` folder to your cPanel `public_html` (or a subdirectory).
- Or unzip locally and open `index.html` in a browser.
This demo contains placeholder images (SVG) and a fake contact form.
